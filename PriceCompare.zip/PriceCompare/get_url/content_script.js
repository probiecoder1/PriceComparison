// content_script.js

// Create a function to handle the click event
function handleClick() {
  // Get the current URL
  var url = window.location.href;
  var trimmedUrl = request.url.split("products/")[1];
  var endIndex = trimmedUrl.indexOf("-i");
  trimmedUrl = trimmedUrl.substring(0, endIndex);
  trimmedUrl=trimmedUrl.replace("-"," ");

  // Display the URL in a dialog box
  alert("Current URL: " + url);
}

// Add a click event listener to the document
document.addEventListener("click", handleClick);
