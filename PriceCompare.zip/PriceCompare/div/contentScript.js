// Create the div element
const div = document.createElement("div");
div.id = "extension-div";

// Set the HTML content
div.innerHTML = `<!DOCTYPE html>
<html lang="en">
  <head>
    <link rel="stylesheet" href="./styles.css" />
    <script src="./script.js" defer></script>
    <style>
      /* Additional CSS styles specific to the embedded HTML */
    </style>
  </head>
  <body>
    <p id="nameDisplayer">Loading...</p>
    <p id="priceDisplayer">Loading...</p>
    <a id="showProduct">Show Other Products</a>
    <a id="gotoSite" href="https://www.dealayo.com/catalogsearch/result/?q="+val target="_blank">View Product on Site</a>
  </body>
</html>`;

// Style the div
div.style.position = "relative";
div.style.width = "50%";
div.style.margin = "0 auto";
div.style.padding = "20px";
div.style.backgroundColor = "rgba(0, 0, 0, 0.8)";
div.style.color = "#fff";
div.style.zIndex = "9999";

// Add the div to the page body
document.documentElement.appendChild(div);
