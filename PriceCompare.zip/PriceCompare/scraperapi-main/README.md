# Scraper API
---

This is a beginner level project using fastapi that scrapes data 
from amazon and displays it in a json format

#### Usage
Install the requirements and run

`uvicorn main:app --reload`

open up your browser and after the root endpoint add an ASIN number

basic data will be returned to you in JSON.

#### Purpose
Educational/learning

#### What next?
Expand on this to include different websites, returning more data.