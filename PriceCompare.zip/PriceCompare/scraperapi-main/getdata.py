import requests
import json
request = requests.get(
    'http://127.0.0.1:8000/samsung-galaxy-a03-core-2gb-ram-32gb-storage-black.html').json()

print(request)
