import sys
import json

from scraper import Scraper

product = Scraper()

url = 'tea'
data_back = product.scrapedata(url)

# Convert the scraped data to JSON
output = {
    "data": data_back
}

# Print the JSON data
print(json.dumps(output))
sys.stdout.flush()
