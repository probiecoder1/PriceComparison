chrome.runtime.onMessage.addListener((message) => {
  const valueDisplay = document.getElementById('valueDisplay');
  valueDisplay.innerText = JSON.stringify(message);
});
