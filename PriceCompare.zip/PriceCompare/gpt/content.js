chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Data received from background script:', message);

  // Access the JSON data and do further processing if needed
  const jsonData = message.data;
  console.log('JSON data:', jsonData);

  // Send the processed value back to the background script
  sendResponse(jsonData);
});
