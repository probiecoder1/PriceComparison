chrome.action.onClicked.addListener(async (tab) => {
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ['content.js'],
  }, async () => {
    const { spawn } = chrome.runtime;
    const pythonProcess = spawn('python', ['python_script.py']);

    let data = '';

    pythonProcess.stdout.on('data', (chunk) => {
      data += chunk.toString();
    });

    pythonProcess.stdout.on('end', () => {
      const message = JSON.parse(data);
      console.log('Data received from Python:', message);

      // Update the popup with the message received from Python
      chrome.action.setPopup({ popup: 'popup.html' });

      // Send the message to the content script
      chrome.tabs.sendMessage(tab.id, { data: message });
    });

    pythonProcess.stderr.on('data', (data) => {
      console.error('Error executing Python script:', data.toString());
    });
  });
});
