chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.url) {
      var urlElement = document.getElementById('url');
      urlElement.textContent = request.url;
    }
  });
  