const nameDisplayer = document.querySelector("#nameDisplayer")
const priceDisplayer = document.querySelector("#priceDisplayer")
const button = document.querySelector("#showProduct")
var val = "food"
const showProduct = async () => {
  const URI = "http://127.0.0.1:8000/"+val
  console.log(URI)
  var currentUrl = window.location.href
  console.log(currentUrl)
  var slicedUrl = currentUrl.slice(currentUrl.indexOf('products/'))
  console.log(slicedUrl)
  const data = await (await fetch(URI)).json()
  const pname = await data.results["name"]
  const pprice = await data.results["price"]

  nameDisplayer.innerText = pname
  priceDisplayer.innerText = pprice
}
showProduct()
button.addEventListener("click", showProduct, { passive: true })

