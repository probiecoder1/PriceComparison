from fastapi import FastAPI

import requests
from bs4 import BeautifulSoup

from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/{asin}")
async def get_data(asin: str):
    session = requests.Session()
    session.headers.update({
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36'
    })
    resp = session.get(
        f"https://www.dealayo.com/{asin}")
    if resp.status_code != 200:
        return {"error": f"bad status code {resp.status_code}"}
    soup = BeautifulSoup(resp.text, "html.parser")
    try:
        data = {
            "asin": asin,
            "name": soup.select_one("h2.product-name").text.strip(),
            "price": soup.select_one("span.price").text.strip(),
        }
        return {"results": data}
    except KeyError:
        return {"error": "Unable to parse page"}
