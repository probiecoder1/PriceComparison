import sys
import json
import ast

data_back = 'Khate'

input = sys.argv[0]
output = data_back
print(output)

#input = ast.literal_eval(sys.argv[1])
#output = input
# output.append(data_back)
# print(json.dumps(output))

sys.stdout.flush()
