const express = require('express');
const { spawnSync } = require('child_process');

const app = express();
const port = 3000;

app.get('/', (req, res) => {
  const data_to_pass_in = 'send this to python script';

  const python_process = spawnSync('python', ['./python.py', data_to_pass_in]);

  if (python_process.error) {
    console.error('Error executing Python script:', python_process.error);
    res.status(500).send('Error executing Python script');
  } else {
    const stdout = python_process.stdout.toString();
    res.send(stdout);
  }
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
