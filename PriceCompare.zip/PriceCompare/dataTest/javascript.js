const spawner = require('child_process').spawn;

const data_to_pass_in = 'send this to python script';

const python_process = spawner('python',['./python.py', JSON.stringify(data_to_pass_in)]);

python_process.stdout.on('data', (data) => {
    console.log('Data received from python script:',data.toString());
    const priceDisplayer = document.querySelector("#priceDisplayer")
    const pprice = data.toString()
    priceDisplayer.innerText = pprice
});

