const nameDisplayer = document.querySelector("#nameDisplayer")
const priceDisplayer = document.querySelector("#priceDisplayer")
const button = document.querySelector("#showProduct")
var global_value = require('./global')

//var val = "shoes+for+men"
const showProduct = async () => {
  const URI = "http://localhost:5000"
  const data =  (await fetch(URI, {
    mode: 'no-cors'}))
  // const pname = await data.results["name"]
  // const pprice = await data.results["price"]
  // console.log(pname)

  nameDisplayer.innerText = global_value
  // priceDisplayer.innerText = pprice
}
showProduct()
button.addEventListener("click", showProduct, { passive: true })

