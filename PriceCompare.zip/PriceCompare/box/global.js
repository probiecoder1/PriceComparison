var global_value ="12344"

module.exports = global_value;