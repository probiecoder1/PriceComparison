// const nameDisplayer = document.querySelector("#nameDisplayer")
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.url) {
    var trimmedUrl = request.url.split("products/")[1];
    var endIndex = trimmedUrl.indexOf("-i");
    if (endIndex !== -1) {
      trimmedUrl = trimmedUrl.substring(0, endIndex);
      trimmedUrl=trimmedUrl.replace("-"," ");
      console.log(trimmedUrl)
      nameDisplayer.innerText = trimmedUrl
    }
  }
});


