from requests_html import HTMLSession


class Scraper():

    def scrapedata(self, tag):
        url = f'https://www.dealayo.com/catalogsearch/result/?q={tag}'
        s = HTMLSession()
        r = s.get(url)
        # print(r.status_code)

        qlist = []

        products = r.html.find('div.product-item-details')

        for p in products:
            data = {
                'name': p.find('h2.product-name', first=True).text.strip(),
                'price': p.find('span.price', first=True).text.strip()
            }
            # print(data)
            qlist.append(data)

        return {"results": data}


product = Scraper()
# product.scrapedata('food')
