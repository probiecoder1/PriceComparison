from flask import Flask, request, jsonify
from requests_html import HTMLSession

app = Flask(__name__)


@app.route('/scrape', methods=['GET'])
def scrape_data():
    url = request.args.get('url')

    s = HTMLSession()
    r = s.get(url)

    qlist = []
    products = r.html.find('div.product-item-details')

    for p in products:
        data = {
            'name': p.find('h2.product-name', first=True).text.strip(),
            'price': p.find('span.price', first=True).text.strip()
        }
        qlist.append(data)

    return jsonify(qlist)


if __name__ == '__main__':
    app.run()
