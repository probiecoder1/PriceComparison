chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.action === "getURL") {
      var url = window.location.href;
      chrome.runtime.sendMessage({ url: url });
    }
  });
  