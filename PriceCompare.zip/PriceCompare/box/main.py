from scraper import Scraper

product = Scraper()

print(product.scrapedata('food'))
