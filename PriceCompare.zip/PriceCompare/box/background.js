chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
    if (changeInfo.status === 'complete') {
      var url = tab.url;
      chrome.runtime.sendMessage({ url: url });
    }
  });
  