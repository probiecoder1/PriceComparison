// file2.js
const importedData = require('./server');

console.log(importedData); // Output: Hello, world!
