// file1.js
const variableData = "Hello!";

module.exports = variableData;
