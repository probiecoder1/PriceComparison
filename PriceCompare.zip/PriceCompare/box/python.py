import sys
import json

from scraper import Scraper

product = Scraper()

url = 'bike'
# print(product.scrapedata(url))

data_back = product.scrapedata(url)

input = sys.argv[0]
print(input)
output = data_back
outputs = json.dumps(output)
print(json.dumps(output))

#input = ast.literal_eval(sys.argv[1])
#output = input
# output.append(data_back)
# print(json.dumps(output))

sys.stdout.flush()
