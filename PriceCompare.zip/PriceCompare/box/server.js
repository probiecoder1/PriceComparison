const express = require('express');
const { spawnSync } = require('child_process');

// const variableData = "Hello!";
// module.exports = variableData;

const app = express();
const port = 5000;

app.get('/', (req, res) => {
  console.log("response ------")
  const data_to_pass_in = 'send this to python script'
  const python_process = spawnSync('python', ['./python.py', data_to_pass_in]);
  //  console.log("PY process",python_process)
  //  module.exports = python_process;

  if (python_process.error) {
    console.error('Error executing Python script:', python_process.error);
    res.status(500).send('Error executing Python script');
    console.log("Error");
    // module.exports = variableData;
    
  } else {
    console.log("Not error")
    const stdout = python_process.stdout.toString();
    // console.log("STDOUT", stdout)
    
    var index = stdout.indexOf("{");
    var result = stdout.substr(index);
    global.global_value = result
    console.log("global_value", global.global_value)
    res.send(global.global_value);
    // module.exports = result;
}
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
